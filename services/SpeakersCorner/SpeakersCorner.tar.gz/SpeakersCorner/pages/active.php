<?php
    function renderPage() {
        echo "Active";
    }
?>
