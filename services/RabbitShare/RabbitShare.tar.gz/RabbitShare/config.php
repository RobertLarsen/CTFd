<?php
    $config = array(
        "max_file_size"    => 1024 * 1024,
        "upload_directory" => "/var/services/RabbitShare/upload",
        "upload_url"       => "/upload/"
    );
?>
